library(testthat)
library(RSocrata)

test_check("RSocrata")
