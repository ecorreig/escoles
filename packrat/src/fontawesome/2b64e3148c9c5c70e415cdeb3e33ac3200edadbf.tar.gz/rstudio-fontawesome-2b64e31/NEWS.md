# fontawesome 0.1.0 (unreleased)

* Added functions `fa()` and `fai()`
