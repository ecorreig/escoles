#' @title wesanderson
#' @name wesanderson
#' @docType package
#' @details list of palettes from Wes Anderson movies
#' @description list of palettes from Wes Anderson movies
NULL
