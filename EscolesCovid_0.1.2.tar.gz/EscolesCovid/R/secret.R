token <- '3EE26EEE6D848A47B4A17BE7CC508FE9'
secret <- 'Zb3yck6ydBPWRUeYtj2T8pM7sN7+yqAj7z5x2Pvi'

# rsconnect::setAccountInfo(name = "projecteorbrita", token = token, secret = secret)
# rsconnect::deployApp("escoles", forceUpdate = T)
#
#

glink <- function() {
  "https://docs.google.com/spreadsheets/d/1JWJUgxpY4z1zb1I65xc6paNRJbxU8bYJsEcH2X8pbPU"
}

mail <- function() {
  "projecte.orbita@gmail.com"
}
