EscolesCovid::launchApp()
